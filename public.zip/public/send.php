<?php

require_once("../includes/initialize.php");

$message = $_GET["message"];
$theid = $_GET["theid"];




echo "success";

?>